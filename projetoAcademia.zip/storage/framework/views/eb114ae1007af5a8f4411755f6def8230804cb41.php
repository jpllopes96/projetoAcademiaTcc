


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="mb-2 text-end">
                    <div>
                        <a href="<?php echo e(route('academia.create')); ?>" class="btn btn-dark">
                            Cadastrar academia <i class="fas fa-plus-circle"></i>
                        </a>
                    </div>
                </div>

                <div class="card bg-dark text-white" style="opacity: .98">
                    <div class="card-body">
                        <h4 class="card-title">Lista de academias</h4>
                        <div class="table-responsive mt-3">

                            <table class="table table-dark table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th><i class="fas fa-sort text-muted"></i> Nome</th>
                                        <th><i class="fas fa-sort text-muted"></i> Email</th>
                                        <th><i class="fas fa-sort text-muted"></i> Enderço</th>
                                        <th><i class="fas fa-sort text-muted"></i> Opções</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php if($academias->count() == 0): ?>
                                        <tr>
                                            <td colspan="5">Nenhuma Academia cadastrada, clique no link para adicionar
                                                uma
                                                nova
                                                academia. <a href="<?php echo e(route('academia.create')); ?>" class="btn btn-link">
                                                    Cadastrar academia <i class="fas fa-plus-circle"></i>
                                                </a></td>
                                        </tr>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $academias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $academia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($academia->id); ?></td>
                                                <td><?php echo e($academia->user->name); ?></td>
                                                <td><?php echo e($academia->user->email); ?></td>
                                                <td> <?php echo e($academia->endereco); ?> </td>
                                                <td class="text-truncate">
                                                    <a href="<?php echo e(route('academia.show', $academia->id)); ?>"
                                                        class="btn btn-secondary" title="Ver">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="<?php echo e(route('academia.edit', $academia->id)); ?>"
                                                        class="btn btn-secondary" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <button type="button" class="btn btn-secondary" title="Excluir"
                                                        data-bs-toggle="modal" data-bs-target="#modelId"
                                                        onclick="document.getElementById('form-delete').action='<?php echo e(route('academia.destroy', $academia->id)); ?>'">
                                                        <i class="fas fa-trash-alt"></i>
                                                    </button>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>


                        <nav aria-label="Page navigation example">
                            <ul class="pagination">
                                <li class="page-item"><a class="page-link"
                                        href="<?php echo e($academias->previousPageUrl()); ?>">Voltar</a></li>
                                <?php for($i = 1; $i <= $academias->lastPage(); $i++): ?>
                                    <li class="page-item <?php echo e($academias->currentPage() == $i ? 'active' : ''); ?>">
                                        <a class="page-link" href="<?php echo e($academias->url($i)); ?>"><?php echo e($i); ?></a>
                                    </li>
                                <?php endfor; ?>
                                <li class="page-item"><a class="page-link"
                                        href="<?php echo e($academias->nextPageUrl()); ?>">Avançar</a></li>
                            </ul>
                        </nav>
                    </div>

                </div>
            </div>

        </div>

    </div>
    <?php echo $__env->make('layouts.modal_excluir_registros', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/academia/index.blade.php ENDPATH**/ ?>