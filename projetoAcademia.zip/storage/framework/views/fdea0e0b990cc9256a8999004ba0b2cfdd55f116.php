

<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card bg-dark text-white pb-4 pt-3">
                    <div class="card-body">
                        <h1 class="card-title mb-3 fw-bold"><?php echo e($academia->user->name); ?></h1>

                        <div>
                            <img src="<?php echo e(asset($academia->img_path)); ?>" width="300" alt="<?php echo e($academia->nome); ?>"
                                class="float-lg-start me-3 mb-3 rounded ">
                            <p class="fs-5">
                                <?php echo e($academia->descricao); ?>

                            </p>

                            <div class="fw-bold text-light opacity-75 my-2">
                                <i class="fas fa-map-marker-alt"></i> <?php echo e($academia->endereco); ?><br>
                                <i class="fas fa-envelope"></i> <?php echo e($academia->user->email); ?>


                            </div>

                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('admin')): ?>
                                <div class=" mt-3">
                                    <a href="<?php echo e(route('academia.edit', $academia->id)); ?>"
                                        class="btn btn-danger btn-sm rounded-pill px-3">
                                        <i class="fas fa-edit"></i> Editar
                                    </a>
                                </div>
                            <?php endif; ?>

                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/academia/show.blade.php ENDPATH**/ ?>