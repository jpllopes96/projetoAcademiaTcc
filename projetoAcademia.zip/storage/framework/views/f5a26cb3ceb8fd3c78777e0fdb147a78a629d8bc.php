<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Treinos do Aluno</title>
</head>

<body>
    <style>
        * {
            font-family: Arial, Helvetica, sans-serif
        }

        h2 {
            font-weight: bold
        }

        .container {
            max-width: 1000px;
            margin: 0 auto;
        }

        table {
            display: table;
            border: 1px solid gray;
            border-collapse: collapse;
            width: 100%
        }

        th,
        td {
            border: 1px solid gray;
            text-align: left;
            padding: 4px 10px;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }


        .tb-head {
            background: #ffd484;
        }
    </style>
    <div class="container mt-5">
        
        <table class="table">
            <tbody>
                <tr>
                    <th class="tb-head" colspan="2" style="text-align:center">IDENTIFICAÇÃO DO ALUNO</th>
                </tr>
                <tr>
                    <th>Nome</th>
                    <td><?php echo e($aluno->user->name); ?></td>
                </tr>
                <tr>
                    <th>E-mail</th>
                    <td><?php echo e($aluno->user->email); ?></td>
                </tr>
                <tr>
                    <th>Gênero</th>
                    <td><?php echo e($aluno->sexo == 'm' ? 'Masculino' : 'Feminino'); ?></td>
                </tr>
                <tr>
                    <th>Data de Nascimento</th>
                    <td><?php echo e(date('d/m/Y', strtotime($aluno->data_nascimento))); ?></td>
                </tr>
                <tr>
                    <th>Telefone</th>
                    <td><?php echo e($aluno->user->celular); ?></td>
                </tr>

            </tbody>
        </table>
        <h1>Treinos</h1>
        <?php $__currentLoopData = $treinos['diasdasemana']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <p class="tb-head" colspan="5" style="text-align:center"><?php echo e($dia); ?> </p>
            <table class="table table-dark table-striped table-hover">
                <thead>
                    <tr>
                        <th>Exercício</th>
                        <th>Séries</th>
                        <th>Repetições</th>
                        <th>Carga</th>
                        <th>Vídeo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(isset($treinos['treinos'][$key])): ?>
                        <?php $__currentLoopData = $treinos['treinos'][$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treino): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($treino->treino); ?></td>
                                <td><?php echo e($treino->series); ?></td>
                                <td><?php echo e($treino->repeticoes); ?></td>
                                <td><?php echo e($treino->carga); ?></td>
                                <td> <?php echo e($treino->video); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="p-3 text-center text-muted">
                                Não há treinos para este dia.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

</body>

</html>
<?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/treino/pdf.blade.php ENDPATH**/ ?>