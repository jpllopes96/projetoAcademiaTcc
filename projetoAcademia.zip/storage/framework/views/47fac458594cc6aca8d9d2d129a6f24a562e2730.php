<style>
    .laravel-embed__responsive-wrapper { position: relative; height: 0; overflow: hidden; max-width: 100%; } 
    .laravel-embed__fallback { background: rgba(0, 0, 0, 0.15); color: rgba(0, 0, 0, 0.7); display: flex; align-items: center; justify-content: center; } 
    .laravel-embed__fallback,
    .laravel-embed__responsive-wrapper iframe,
    .laravel-embed__responsive-wrapper object,
    .laravel-embed__responsive-wrapper embed { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }
</style><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\vendor\bensampo\laravel-embed\src/../resources/views/components/styles.blade.php ENDPATH**/ ?>