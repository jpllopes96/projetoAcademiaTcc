<!-- Modal -->
<div class="modal fade " id="model-edit" tabindex="-1" role="dialog" aria-labelledby="modelEdit" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Editar Treino</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('treino.update')); ?>" method="post">
                <div class="modal-body">

                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <input type="hidden" name="edit_id" id="edit-id" value="<?php echo e(old('edit_id')); ?>">
                    <input type="hidden" name="id_aluno" value="<?php echo e($idAluno); ?>">

                    <div class="mb-3">
                        <label for="edit-nome" class="form-label">Nome do treino</label>
                        <input type="text" value="<?php echo e(old('edit_nome')); ?>"
                            class="form-control <?php $__errorArgs = ['edit_nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="edit_nome"
                            id="edit-nome" required>
                        <?php $__errorArgs = ['edit_nome'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback"> <?php echo e($message); ?> </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="row">
                        <div class="mb-3 col-12 col-lg-6">
                            <label for="edit-series" class="form-label">Séries</label>
                            <input type="text" value="<?php echo e(old('edit_series')); ?>"
                                class="form-control <?php $__errorArgs = ['edit_series'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="edit_series"
                                id="edit-series" onkeypress="return event.charCode >= 48 && event.charCode <= 57"
                                required>
                            <?php $__errorArgs = ['edit_series'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"> <?php echo e($message); ?> </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-lg-6">
                            <label for="edit-repeticoes" class="form-label">Repetições</label>
                            <input type="text" value="<?php echo e(old('edit_repeticoes')); ?>"
                                class="form-control <?php $__errorArgs = ['edit_repeticoes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="edit_repeticoes" id="edit-repeticoes" required>
                            <?php $__errorArgs = ['edit_repeticoes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"> <?php echo e($message); ?> </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-lg-6">
                            <label for="edit-carga" class="form-label">Carga</label>
                            <input type="text" value="<?php echo e(old('edit_carga')); ?>"
                                class="form-control <?php $__errorArgs = ['edit_carga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="edit_carga"
                                id="edit-carga">
                            <?php $__errorArgs = ['edit_carga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"> <?php echo e($message); ?> </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3 col-12 col-lg-6">
                            <label for="edit-video" class="form-label">Vídeo</label>
                            <input type="text" value="<?php echo e(old('edit_video')); ?>"
                                class="form-control <?php $__errorArgs = ['edit_video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="edit_video"
                                id="edit-video">
                            <?php $__errorArgs = ['edit_video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <div class="invalid-feedback"> <?php echo e($message); ?> </div>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-primary">Atualizar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/treino/modal_edit.blade.php ENDPATH**/ ?>