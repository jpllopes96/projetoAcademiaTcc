

<?php $__env->startSection('content'); ?>
    <div class="container">

        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card bg-dark text-white">
                    <div class="card-body">
                        <h4 class="card-title m-0 p-0  h3"><?php echo e($aluno->user->name); ?></h4>
                        <span class="text-muted">Aluno(a)</span>

                        <div class="mt-3 fs-5">
                            <div>
                                <span class="text-info"> <i class="fas fa-envelope"></i> E-mail: </span>
                                <?php echo e($aluno->user->email); ?>

                            </div>
                            <div>
                                <span class="text-info"> <i class="fas fa-phone-square-alt"></i> Celular: </span>
                                <?php echo e($aluno->user->celular); ?>

                            </div>
                            <div>
                                <span class="text-info"> <i class="far fa-id-card"></i> CPF: </span>
                                <?php echo e($aluno->cpf); ?>

                            </div>
                            <div>
                                <span class="text-info"> <i class="fas fa-calendar-alt"></i> Data de nascimento:
                                </span>
                                <?php echo e(date('d/m/Y', strtotime($aluno->data_nascimento))); ?>

                            </div>

                            <div class="mb-4">
                                <span class="text-info"> <i class="fas fa-venus-mars"></i> Sexo: </span>
                                <?php if($aluno->sexo == 'm'): ?>
                                    Masculino
                                <?php else: ?>
                                    Feminino
                                <?php endif; ?>
                            </div>
                            <a href="<?php echo e(route('aluno.edit', $aluno->id)); ?>"
                                class="btn btn-warning px-3 rounded-pill btn-sm">
                                <i class="fas fa-edit"></i> Editar
                            </a>

                            <a href="<?php echo e(route('treino.create', $aluno->id)); ?>"
                                class="btn btn-primary px-3 rounded-pill btn-sm">
                                <i class="fas fa-dumbbell"></i> Treinos
                            </a>
                        </div>
                    </div>
                </div>


            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/aluno/show.blade.php ENDPATH**/ ?>