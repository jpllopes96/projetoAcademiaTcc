<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 56.25%"
>
    <iframe 
        src="https://www.youtube-nocookie.com/embed/4m72jsC_5Ro" 
        frameborder="0" 
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" 
        allowfullscreen>
    </iframe>
</div><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\storage\framework\views/54ba054e3bab76409e8b554dfe04ae943bf36eb0.blade.php ENDPATH**/ ?>