<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!--video youtube -->

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="<?php echo e(asset('js/iziToast.min.js')); ?>"></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

    <!-- icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css"
        integrity="sha512-9usAa10IRO0HhonpyAIVpjrylPvoDwiPUiKdWk5t3PyolY1cOd4DSE0Ga+ri4AuTroPR5aQvXU9xC6qOPnzFeg=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/iziToast.min.css')); ?>">

    <!-- Alertas -->
    <link rel="stylesheet" href="<?php echo e(asset('css/iziToast.css')); ?>">

    <?php if (isset($component)) { $__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187 = $component; } ?>
<?php $component = $__env->getContainer()->make(BenSampo\Embed\ViewComponents\StylesViewComponent::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('embed-styles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(BenSampo\Embed\ViewComponents\StylesViewComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187)): ?>
<?php $component = $__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187; ?>
<?php unset($__componentOriginale8b63b57f913e31975c2f4821cbdb5543cd83187); ?>
<?php endif; ?>


</head>

<body>
    <div id="app">
        <?php echo $__env->make('layouts.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        

        <main class="py-4">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
    <?php if(session('msg_sucesso')): ?>
        <script>
            iziToast.success({
                title: 'OK',
                message: "<?php echo e(session('msg_sucesso')); ?>",
                position: 'topRight',
            });
        </script>
    <?php endif; ?>
    <?php if(session('msg_erro')): ?>
        <script>
            iziToast.error({
                title: 'Error',
                message: "<?php echo e(session('msg_erro')); ?>",
                position: 'topRight',
            });
        </script>
    <?php endif; ?>



</body>

</html>
<?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/layouts/app.blade.php ENDPATH**/ ?>