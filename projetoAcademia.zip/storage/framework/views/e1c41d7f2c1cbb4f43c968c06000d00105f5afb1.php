<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 56.25%"
>
    <iframe 
        src="https://www.youtube-nocookie.com/embed/sqOw2Y6uDWQ" 
        frameborder="0" 
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" 
        allowfullscreen>
    </iframe>
</div><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\storage\framework\views/07bdebf3b42c7eaf280b7d09ab758e9b4312ef2c.blade.php ENDPATH**/ ?>