<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 56.25%"
>
    <iframe 
        src="https://www.youtube-nocookie.com/embed/sqOw2Y6uDWQ" 
        frameborder="0" 
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" 
        allowfullscreen>
    </iframe>
</div>