

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card bg-dark text-white">
                    <div class="card-body">
                        <h3 class="card-title mb-4 h4 fw-bold">Aluno: <span
                                class="text-info"><?php echo e($aluno->user->name); ?></span>
                        </h3>
                        <h4 class="card-title mb-3 h5">Treino</h4>
                        <form action="<?php echo e(route('treino.store', $aluno->id)); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="row row-cols-1 row-cols-lg-4 align-items-start gy-3">
                                <div>
                                    <div>
                                        <label for="dia" class="form-label">Dia da semana</label>
                                        <select class="form-select <?php $__errorArgs = ['semana_dia_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                            name=" semana_dia_id" id="dia">
                                            <?php $__currentLoopData = $diasDaSemana; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dia->id); ?>"
                                                    <?php if((request()->get('dia_da_semana') ?? 1) == $dia->id): ?> selected <?php endif; ?>>
                                                    <?php echo e($dia->dia); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <?php $__errorArgs = ['semana_dia_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                                <div>
                                    <label for="treino" class="form-label">Treino</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['treino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="treino" id="treino" value="<?php echo e(old('treino')); ?>"
                                        placeholder="Nome do treino" required>
                                    <?php $__errorArgs = ['treino'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div>
                                    <label for="series" class="form-label">Séries</label>
                                    <input type="number" min="0"
                                        class="form-control <?php $__errorArgs = ['series'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="series"
                                        id="series" value="<?php echo e(old('series')); ?>" placeholder="Séries"
                                        onkeypress="return event.charCode >= 48 && event.charCode <= 57" required>
                                    <?php $__errorArgs = ['series'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div>
                                    <label for="repeticoes" class="form-label">Repetições</label>
                                    <input type="text" min="0"
                                        class="form-control <?php $__errorArgs = ['repeticoes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="repeticoes"
                                        id="repeticoes" value="<?php echo e(old('repeticoes')); ?>" placeholder="Repetições" required>
                                    <?php $__errorArgs = ['repeticoes'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div>
                                    <label for="carga" class="form-label">Carga</label>
                                    <input type="text" min="0"
                                        class="form-control <?php $__errorArgs = ['carga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="carga"
                                        id="carga" value="<?php echo e(old('carga')); ?>" placeholder="Carga">
                                    <?php $__errorArgs = ['carga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div>
                                    <label for="video" class="form-label">Vídeo</label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                        name="video" id="video" value="<?php echo e(old('video')); ?>"
                                        placeholder="https://youtube.com/">
                                    <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <div class="invalid-feedback"><?php echo e($message); ?></div>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div>
                                    <label for="" class="form-label w-100 opacity-0">Adicionar</label>
                                    <button type="submit" class="btn btn-warning d-block w-100"><i class="fas fa-plus"></i>
                                        Adicionar</button>
                                </div>
                            </div>
                        </form>

                        <hr>

                        <div class="table-responsive mt-3">
                            <table class="table table-dark table-striped table-hover">
                                <thead>
                                    <tr>
                                        <th>Treino</th>
                                        <th>Séries</th>
                                        <th>Repetições</th>
                                        <th>Carga</th>
                                        <th>Vídeo</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $treinosParaDiaSelecionado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->treino); ?></td>
                                            <td><?php echo e($item->series); ?></td>
                                            <td><?php echo e($item->repeticoes); ?></td>
                                            <td><?php echo e($item->carga); ?></td>
                                            <td><?php echo e($item->video); ?></td>
                                            <td class="col-2 text-truncate">
                                                <button type="button" class="btn btn-primary btn-sm px-3"
                                                    data-bs-toggle="modal" data-bs-target="#model-edit"
                                                    onclick='setDadosEditTreino(`<?= $item ?>`)'>
                                                    Editar
                                                </button>

                                                <form class="d-inline-block"
                                                    action="<?php echo e(route('treino.destroy', $item->id)); ?>" method="post">
                                                    <?php echo method_field('DELETE'); ?>
                                                    <?php echo csrf_field(); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm px-3">
                                                        Excluir
                                                    </button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                            <?php if(count($treinosParaDiaSelecionado) == 0): ?>
                                <div class="alert text-muted">
                                    Não há treinos para o dia selecionado.
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('treino.modal_edit', ['idAluno' => $aluno->user_id], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <button type="button" id="model-edit-btn" class="btn btn-primary btn-lg visually-hidden" data-bs-toggle="modal"
        data-bs-target="#model-edit">
    </button>
    <?php if($errors->first('edit_nome') || $errors->first('edit_series') || $errors->first('edit_repeticoes')): ?>
        <script>
            document.getElementById('model-edit-btn').click()
        </script>
    <?php endif; ?>
    <script>
        // redireciona ao selecionar dia da semana
        document.getElementById('dia').onchange = function() {
            let el = document.getElementById('dia');
            let idSeleconado = el.options[el.selectedIndex].value;
            window.location.href = '<?php echo e(route('treino.create', $aluno->id)); ?>?dia_da_semana=' + idSeleconado
        }


        function setDadosEditTreino(data) {
            data = JSON.parse(data)
            console.log(data)
            document.getElementById('edit-nome').value = data.treino
            document.getElementById('edit-series').value = data.series
            document.getElementById('edit-repeticoes').value = data.repeticoes
            document.getElementById('edit-carga').value = data.carga
            document.getElementById('edit-video').value = data.video
            document.getElementById('edit-id').value = data.id
            cancelarEdit()
        }

        function cancelarEdit() {
            for (let int = 0; int <= 30; int++) {
                for (let i in document.getElementsByClassName('is-invalid')) {
                    document.getElementsByClassName('is-invalid')[i].className = 'form-control'
                }
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/treino/create.blade.php ENDPATH**/ ?>