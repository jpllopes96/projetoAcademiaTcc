<?php if (isset($component)) { $__componentOriginale355957cf9973b635c7d92da4b5b96326294fc1d = $component; } ?>
<?php $component = $__env->getContainer()->make(BenSampo\Embed\ViewComponents\ResponsiveWrapperViewComponent::class, ['aspectRatio' => $aspectRatio] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('embed-responsive-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(BenSampo\Embed\ViewComponents\ResponsiveWrapperViewComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <iframe 
        src="https://www.youtube-nocookie.com/embed/<?php echo e($videoId); ?>" 
        frameborder="0" 
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" 
        allowfullscreen>
    </iframe>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale355957cf9973b635c7d92da4b5b96326294fc1d)): ?>
<?php $component = $__componentOriginale355957cf9973b635c7d92da4b5b96326294fc1d; ?>
<?php unset($__componentOriginale355957cf9973b635c7d92da4b5b96326294fc1d); ?>
<?php endif; ?>
<?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\vendor\bensampo\laravel-embed\src/../resources/views/services/youtube.blade.php ENDPATH**/ ?>