<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 75%"
>
    <iframe 
        src="https://www.youtube-nocookie.com/embed/sqOw2Y6uDWQ" 
        frameborder="0" 
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" 
        allowfullscreen>
    </iframe>
</div><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\storage\framework\views/b49794a43891b57a61198b38a2392459c2d5da80.blade.php ENDPATH**/ ?>