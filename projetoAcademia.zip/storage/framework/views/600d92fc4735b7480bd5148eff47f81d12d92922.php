


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">


            
            <?php $__env->startComponent('aluno.component.table_listar_alunos', ['alunos' => $alunos]); ?>
            <?php echo $__env->renderComponent(); ?>

        </div>

    </div>
    <?php echo $__env->make('layouts.modal_excluir_registros', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/aluno/index.blade.php ENDPATH**/ ?>