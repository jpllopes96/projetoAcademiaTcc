<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 75%"
>
    <iframe 
        src="https://www.youtube-nocookie.com/embed/4m72jsC_5Ro" 
        frameborder="0" 
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" 
        allowfullscreen>
    </iframe>
</div><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\storage\framework\views/a3c2526972ccf3513461104658d61298a5a4d5f6.blade.php ENDPATH**/ ?>