<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-lg-5 py-4 mt-5" style="max-width: 400px">

                <div class="card bg-white text-dark rounded-lg fw-light shadow-lg">
                    <div class="card-body p-4">

                        <h1 class="text-center fw-bold fs-5 mb-4 "><?php echo e(__('Login')); ?></h1>
                        <?php if(session('erro_login_social')): ?>
                            <div class="alert alert-danger text-center" role="alert">
                                <strong>Login do <?php echo e(session('erro_login_social')); ?> não autorizado</strong>
                            </div>
                        <?php endif; ?>

                        <h2 class="visually-hidden">Login com rede social</h2>
                        <div class="text-center d-flex justify-content-center align-items-center gap-2">
                            <a href="<?php echo e(route('social.login', ['provider' => 'github'])); ?>" class="text-color-github"
                                title="Github">
                                <i class="fab fa-github fa-3x"></i>
                            </a>
                            <a href="<?php echo e(route('social.login', ['provider' => 'google'])); ?>" title="Google">
                                <img src="<?php echo e(asset('imagens/icons/google.svg')); ?>" width="40">
                            </a>
                            <a href="<?php echo e(route('social.login', ['provider' => 'linkedin'])); ?>" class="text-color-linkedin "
                                title="Linkedin">
                                <i class="fab fa-linkedin fa-3x"></i>
                            </a>
                        </div>

                        <div class="fw-lighter text-center text-muted mb-4">ou preencha abaixo</div>


                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="row mb-3">
                                <label for="email"
                                    class="col-form-label visually-hidden"><?php echo e(__('Email Address')); ?></label>


                                <input id="email" type="email" placeholder="E-mail"
                                    class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="email"
                                    value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus>

                                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            </div>

                            <div class="row mb-3">
                                <label for="password" class="col-form-label visually-hidden"><?php echo e(__('Password')); ?></label>


                                <input id="password" type="password" placeholder="Senha"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" required
                                    autocomplete="current-password">

                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>

                            <div class="row mb-3">

                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="remember" id="remember"
                                        <?php echo e(old('remember') ? 'checked' : ''); ?>>

                                    <label class="form-check-label" for="remember">
                                        <?php echo e(__('Remember Me')); ?>

                                    </label>
                                </div>

                            </div>

                            <div class="row mb-0">
                                <div class=" ">
                                    <button type="submit" class="btn btn-warning  w-100">
                                        <?php echo e(__('Login')); ?>

                                    </button>

                                    <?php if(Route::has('password.request')): ?>
                                        <a class="btn btn-link text-dark w-100" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Forgot Your Password?')); ?>

                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appHome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/auth/login.blade.php ENDPATH**/ ?>