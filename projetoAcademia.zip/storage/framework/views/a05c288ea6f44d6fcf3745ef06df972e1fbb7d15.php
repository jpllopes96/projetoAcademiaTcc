


<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">


            
            <div class="mb-2 text-end mt-5">
                <div>
                    <a href="<?php echo e(route('aluno.create')); ?>" class="btn btn-warning">
                        Cadastrar Aluno <i class="fas fa-plus-circle"></i>
                    </a>
                </div>
            </div>


            <div class="card bg-dark text-white" style="opacity: .98">
                <div class="card-body">
                    <h4 class="card-title">Lista Alunos</h4>
                    <div class="table-responsive mt-3">

                        <table class="table table-dark table-striped table-hover">
                            <thead>
                                <tr>
                                    <th><i class="fas fa-sort text-muted"></i> Nome</th>
                                    <th><i class="fas fa-sort text-muted"></i> Celular</th>
                                    <th><i class="fas fa-sort text-muted"></i> E-mail</th>
                                    <th><i class="fas fa-sort text-muted"></i> Opções</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if(count($alunos) == 0): ?>
                                    <tr>
                                        <td colspan="5">Nenhum Aluno cadastrado, clique no link para adicionar um
                                            novo
                                            Aluno. <a href="<?php echo e(route('aluno.create')); ?>" class="btn btn-link">
                                                Cadastrar Aluno
                                            </a></td>
                                    </tr>
                                <?php else: ?>
                                    <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($aluno->user->name); ?></td>
                                            <td><?php echo e($aluno->user->celular); ?></td>
                                            <td><?php echo e($aluno->user->email); ?></td>
                                            <td class="text-truncate">
                                                <a href="<?php echo e(route('treino.create', $aluno->id)); ?>"
                                                    class="btn btn-secondary" title="Treinos">
                                                    <i class="fas fa-dumbbell"></i>
                                                </a>
                                                <a href="<?php echo e(route('aluno.show', $aluno->id)); ?>" class="btn btn-secondary"
                                                    title="Ver">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                                <a href="<?php echo e(route('aluno.edit', $aluno->id)); ?>" class="btn btn-secondary"
                                                    title="Editar">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <button type="button" class="btn btn-secondary" title="Excluir"
                                                    data-bs-toggle="modal" data-bs-target="#modelId"
                                                    onclick="document.getElementById('form-delete').action='<?php echo e(route('aluno.destroy', $aluno->id)); ?>'">
                                                    <i class="fas fa-trash-alt"></i>
                                                </button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php echo $__env->make('layouts.modal_excluir_registros', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/aluno/resultado_pesquisa.blade.php ENDPATH**/ ?>