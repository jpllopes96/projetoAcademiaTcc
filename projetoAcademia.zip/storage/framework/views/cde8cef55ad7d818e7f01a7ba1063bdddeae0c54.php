<div class="mb-2 text-end mt-5">
    <div>
        <a href="<?php echo e(route('aluno.create')); ?>" class="btn btn-warning">
            Cadastrar Aluno <i class="fas fa-plus-circle"></i>
        </a>
    </div>
</div>


<div class="card bg-dark text-white" style="opacity: .98">
    <div class="card-header">Lista Alunos</div>
    <div class="card-body">
        <div class="table-responsive mt-3">

            <table class="table table-dark table-striped table-hover">
                <thead>
                    <tr>
                        <th><i class="fas fa-sort text-muted"></i> Nome</th>
                        <th><i class="fas fa-sort text-muted"></i> Celular</th>
                        <th><i class="fas fa-sort text-muted"></i> E-mail</th>
                        <th><i class="fas fa-sort text-muted"></i> Opções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if($alunos->count() == 0): ?>
                        <tr>
                            <td colspan="5">Nenhum Aluno cadastrado, clique no link para adicionar um
                                novo
                                Aluno. <a href="<?php echo e(route('aluno.create')); ?>" class="btn btn-link">
                                    Cadastrar Aluno
                                </a></td>
                        </tr>
                    <?php else: ?>
                        <?php $__currentLoopData = $alunos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $aluno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td style="min-width: 10ch;"><?php echo e($aluno->user->name); ?></td>
                                <td style="min-width: 16ch;"><?php echo e($aluno->user->celular); ?></td>
                                <td><?php echo e($aluno->user->email); ?></td>
                                <td class="text-truncate">
                                    <a href="<?php echo e(route('treino.create', $aluno->id)); ?>" class="btn btn-secondary"
                                        title="Treinos">
                                        <i class="fas fa-dumbbell"></i>
                                    </a>
                                    <a href="<?php echo e(route('aluno.show', $aluno->id)); ?>" class="btn btn-secondary"
                                        title="Ver">
                                        <i class="fas fa-eye"></i>
                                    </a>
                                    <a href="<?php echo e(route('aluno.edit', $aluno->id)); ?>" class="btn btn-secondary"
                                        title="Editar">
                                        <i class="fas fa-edit"></i>
                                    </a>
                                    <button type="button" class="btn btn-secondary" title="Excluir"
                                        data-bs-toggle="modal" data-bs-target="#modelId"
                                        onclick="document.getElementById('form-delete').action='<?php echo e(route('aluno.destroy', $aluno->id)); ?>'">
                                        <i class="fas fa-trash-alt"></i>
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>


        <nav aria-label="Page navigation example">
            <ul class="pagination">
                <li class="page-item"><a class="page-link" href="<?php echo e($alunos->previousPageUrl()); ?>">Voltar</a></li>
                <?php for($i = 1; $i <= $alunos->lastPage(); $i++): ?>
                    <li class="page-item <?php echo e($alunos->currentPage() == $i ? 'active' : ''); ?>">
                        <a class="page-link" href="<?php echo e($alunos->url($i)); ?>"><?php echo e($i); ?></a>
                    </li>
                <?php endfor; ?>
                <li class="page-item"><a class="page-link" href="<?php echo e($alunos->nextPageUrl()); ?>">Avançar</a>
                </li>
            </ul>
        </nav>
    </div>
    <script type="module" src="<?php echo e(asset('js/config-inputs-smask.js')); ?>"></script>

</div>
<?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\resources\views/aluno/component/table_listar_alunos.blade.php ENDPATH**/ ?>