<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 56.25%"
>
    <iframe 
        src="https://www.youtube-nocookie.com/embed/4YCLRpKY1cs" 
        frameborder="0" 
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture" 
        allowfullscreen>
    </iframe>
</div><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\storage\framework\views/7bcdd75364526ed2a8e5b87d431702ea532217c9.blade.php ENDPATH**/ ?>