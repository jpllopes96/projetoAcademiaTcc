<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: <?php echo e($aspectRatio->asPercentage()); ?>%"
>
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\JP\Documents\tccProjeto\projetoAcademia\vendor\bensampo\laravel-embed\src/../resources/views/components/responsive-wrapper.blade.php ENDPATH**/ ?>